import json
import os
import pandas as pd
METRICS_ROOT = "D:/BaiduNetdiskDownload/top_300_metrics"  
RAW_DATA_PATH = "data/raw_data"  # 原始数据保存路径，文件名不变
os.makedirs(RAW_DATA_PATH, exist_ok=True)
pr_data = []
for root, dirs, files in os.walk(METRICS_ROOT):
    if root == METRICS_ROOT:
        continue
    domain = os.path.basename(root)
    activity_file = os.path.join(root, "activity_details.json")
    
    if os.path.exists(activity_file):
        try:
            with open(activity_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            values = [item[1] for item in data if isinstance(item, list) and len(item)>=2 and isinstance(item[1], (int, float))]
            avg_pr = round(sum(values)/len(values), 2) if values else None
            if avg_pr is not None:
                pr_data.append({"领域名称": domain, "PR平均时长(天)": avg_pr})
        except:
            continue
pr_json_path = os.path.join(RAW_DATA_PATH, "pr_duration.json")
with open(pr_json_path, "w", encoding="utf-8") as f:
    json.dump(pr_data, f, ensure_ascii=False, indent=4)
repo_data = []
for root, dirs, files in os.walk(METRICS_ROOT):
    if root == METRICS_ROOT:
        continue
    domain = os.path.basename(root)
    domain_info = {"领域名称": domain}
    stars_file = os.path.join(root, "stars.json")
    if os.path.exists(stars_file):
        try:
            with open(stars_file, "r", encoding="utf-8") as f:
                stars_data = json.load(f)
            stars = sum(item.get("stars", 0) for item in stars_data) if isinstance(stars_data, list) else stars_data.get("stars", 0) if isinstance(stars_data, dict) else int(stars_data) if isinstance(stars_data, (int, float)) else None
            domain_info["星标数"] = stars
        except:
            domain_info["星标数"] = None
    fork_file = os.path.join(root, "technical_fork.json")
    if os.path.exists(fork_file):
        try:
            with open(fork_file, "r", encoding="utf-8") as f:
                fork_data = json.load(f)
            forks = sum(item.get("forks", 0) for item in fork_data) if isinstance(fork_data, list) else fork_data.get("forks", 0) if isinstance(fork_data, dict) else int(fork_data) if isinstance(fork_data, (int, float)) else None
            domain_info["Fork数"] = forks
        except:
            domain_info["Fork数"] = None
    contrib_file = os.path.join(root, "contributor_email_suffixes.json")
    if os.path.exists(contrib_file):
        try:
            with open(contrib_file, "r", encoding="utf-8") as f:
                contrib_data = json.load(f)
            contrib_count = sum(contrib_data.values()) if isinstance(contrib_data, dict) else len(contrib_data) if isinstance(contrib_data, list) else None
            suffix_types = len(contrib_data.keys()) if isinstance(contrib_data, dict) else len({email.split("@")[-1] for email in contrib_data if "@" in email}) if isinstance(contrib_data, list) else None
            domain_info["贡献者数量"] = contrib_count
            domain_info["邮箱后缀种类数"] = suffix_types
        except:
            domain_info["贡献者数量"] = None
            domain_info["邮箱后缀种类数"] = None

    repo_data.append(domain_info)
repo_df = pd.DataFrame(repo_data)
for col in ["星标数", "Fork数", "贡献者数量", "邮箱后缀种类数"]:
    repo_df[col] = pd.to_numeric(repo_df[col], errors="coerce").fillna("").astype(object)
repo_csv_path = os.path.join(RAW_DATA_PATH, "repo-list.csv")
repo_df.to_csv(repo_csv_path, index=False, encoding="utf-8-sig")

print(f"✅ 两个数据文件生成完成！")
print(f"📄 pr_duration.json 路径：{pr_json_path}")
print(f"📄 repo-list.csv     路径：{repo_csv_path}")
print(f"\npr_duration.json 包含字段：领域名称、PR平均时长(天)")
print(f"repo-list.csv 包含字段：领域名称、星标数、Fork数、贡献者数量、邮箱后缀种类数")