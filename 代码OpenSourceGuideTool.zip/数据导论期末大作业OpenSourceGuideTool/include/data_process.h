#ifndef DATA_PROCESS_H
#define DATA_PROCESS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct {
    char domain_name[50];      
    int contributor_count;      
    int activity_score;        
    int comprehensive_score;    
    float pr_avg_duration;     
} DomainMetric;
int read_topic_data(const char* file_path, DomainMetric metrics[], int max_count);
int write_topic_data(const char* file_path, DomainMetric metrics[], int count);
int read_pr_duration(const char* file_path, float pr_durations[3]);
float extract_activity_average(const char* json_path);
int count_contributors(const char* json_path);

#endif // DATA_PROCESS_H