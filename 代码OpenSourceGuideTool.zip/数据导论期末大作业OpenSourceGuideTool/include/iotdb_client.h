#ifndef IOTDB_CLIENT_H
#define IOTDB_CLIENT_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define IOTDB_HOST "127.0.0.1"
#define IOTDB_PORT 6667
#define IOTDB_USER "root"
#define IOTDB_PASSWORD "root"
#define IOTDB_STORAGE_GROUP "root.ln"
#define IOTDB_TABLE "topic_metrics"
typedef struct {
    char host[50];
    int port;
} Session;

typedef struct {
    char data[1024];
} SessionDataSet;
#define SUCCESS_STATUS 0
Session* session_new();
int session_open(Session *s, const char* host, int port, const char* user, const char* pwd);
void session_close(Session *s);
void session_free(Session *s);
int session_set_storage_group(Session *s, const char* sg);
int session_execute_non_query(Session *s, const char* sql);
SessionDataSet* session_execute_query(Session *s, const char* sql);
void session_close_dataset(SessionDataSet *ds);
long long session_dataset_get_long(SessionDataSet *ds, int idx);
const char* session_dataset_get_string(SessionDataSet *ds, int idx);
double session_dataset_get_double(SessionDataSet *ds, int idx);
int session_dataset_next(SessionDataSet *ds);
void *iotdb_connect();
void iotdb_disconnect(void *conn);
int iotdb_create_topic_table(void *conn);
int iotdb_import_from_csv(void *conn, const char *csv_path);
char *iotdb_query_topic_data(void *conn, const char *start_date, const char *end_date);

#endif // IOTDB_CLIENT_H