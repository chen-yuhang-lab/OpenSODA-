#ifndef COMMON_UTILS_H
#define COMMON_UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int split_string(const char *str, char delim, char ***result, int max_count);

#endif // COMMON_UTILS_H