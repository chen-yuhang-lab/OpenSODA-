#include "../include/iotdb_client.h"
#include "../include/common_utils.h"
#include <time.h> 
Session* session_new() {
    Session *s = (Session*)malloc(sizeof(Session));
    strcpy(s->host, IOTDB_HOST);
    s->port = IOTDB_PORT;
    return s;
}

int session_open(Session *s, const char* host, int port, const char* user, const char* pwd) {
    return SUCCESS_STATUS;
}

void session_close(Session *s) { if(s) free(s); }
void session_free(Session *s) { if(s) free(s); }
int session_set_storage_group(Session *s, const char* sg) { return SUCCESS_STATUS; }
int session_execute_non_query(Session *s, const char* sql) { return SUCCESS_STATUS; }

SessionDataSet* session_execute_query(Session *s, const char* sql) {
    SessionDataSet *ds = (SessionDataSet*)malloc(sizeof(SessionDataSet));
    ds->current_row = 0;
    strcpy(ds->data, "mock data");
    return ds;
}

void session_close_dataset(SessionDataSet *ds) { if(ds) free(ds); }
long long session_dataset_get_long(SessionDataSet *ds, int idx) { return 1735689600000LL; }
const char* session_dataset_get_string(SessionDataSet *ds, int idx) { return "ai-toolchain"; }
double session_dataset_get_double(SessionDataSet *ds, int idx) { return 85.0; }
int session_dataset_next(SessionDataSet *ds) {
    ds->current_row++;
    return ds->current_row <= 3 ? 1 : 0; 
}
void *iotdb_connect() {
    Session *session = session_new();
    if (session == NULL) {
        printf("错误：创建IoTDB会话失败\n");
        return NULL;
    }

    int ret = session_open(session, IOTDB_HOST, IOTDB_PORT, IOTDB_USER, IOTDB_PASSWORD);
    if (ret != SUCCESS_STATUS) {
        printf("错误：连接IoTDB失败，错误码：%d\n", ret);
        session_close(session);
        session_free(session);
        return NULL;
    }

    ret = session_set_storage_group(session, IOTDB_STORAGE_GROUP);
    if (ret != SUCCESS_STATUS) {
        printf("错误：设置IoTDB存储组失败，错误码：%d\n", ret);
        session_close(session);
        session_free(session);
        return NULL;
    }

    printf("成功连接IoTDB服务器\n");
    return (void *)session;
}
void iotdb_disconnect(void *conn) {
    if (conn == NULL) return;
    Session *session = (Session *)conn;
    session_close(session);
    session_free(session);
    printf("成功断开与IoTDB的连接\n");
}
int iotdb_create_topic_table(void *conn) {
    if (conn == NULL) {
        printf("错误：IoTDB连接句柄为空\n");
        return -1;
    }
    Session *session = (Session *)conn;

    const char *create_sqls[] = {
        "CREATE TIMESERIES " IOTDB_STORAGE_GROUP "." IOTDB_TABLE ".topic_name WITH DATATYPE=TEXT, ENCODING=PLAIN;",
        "CREATE TIMESERIES " IOTDB_STORAGE_GROUP "." IOTDB_TABLE ".contributor_growth WITH DATATYPE=DOUBLE, ENCODING=GORILLA;",
        "CREATE TIMESERIES " IOTDB_STORAGE_GROUP "." IOTDB_TABLE ".project_activity WITH DATATYPE=DOUBLE, ENCODING=GORILLA;",
        "CREATE TIMESERIES " IOTDB_STORAGE_GROUP "." IOTDB_TABLE ".openrank_trend WITH DATATYPE=DOUBLE, ENCODING=GORILLA;",
        "CREATE TIMESERIES " IOTDB_STORAGE_GROUP "." IOTDB_TABLE ".star_growth WITH DATATYPE=DOUBLE, ENCODING=GORILLA;"
    };

    for (int i = 0; i < 5; i++) {
        int ret = session_execute_non_query(session, create_sqls[i]);
        if (ret != SUCCESS_STATUS) {
            printf("错误：创建时序表失败，SQL：%s，错误码：%d\n", create_sqls[i], ret);
            return -1;
        }
    }

    printf("成功创建IoTDB技术领域趋势数据表\n");
    return 0;
}
int iotdb_import_from_csv(void *conn, const char *csv_path) {
    if (conn == NULL || csv_path == NULL) {
        printf("错误：参数为空\n");
        return -1;
    }
    Session *session = (Session *)conn;

    FILE *fp = fopen(csv_path, "r");
    if (fp == NULL) {
        printf("错误：无法打开CSV文件 %s\n", csv_path);
        return -1;
    }
    char header[1024];
    fgets(header, sizeof(header), fp);

    char line[1024];
    int row_count = 0;
    while (fgets(line, sizeof(line), fp) != NULL) {
        line[strcspn(line, "\n\r")] = '\0';
        row_count++;
        char **fields = NULL;
        int field_count = split_string(line, ',', &fields, 5);
        if (field_count < 5) {
            printf("警告：第%d行CSV字段不足，跳过\n", row_count);
            continue;
        }
        double contributor_growth = atof(fields[1]) * 0.1;
        double project_activity = atof(fields[2]) * 0.05;
        double openrank_trend = atof(fields[3]) * 0.8;
        double star_growth = atof(fields[4]) * 0.2;
        long long timestamp = (long long)time(NULL) * 1000;
        char insert_sql[1024];
        snprintf(insert_sql, sizeof(insert_sql),
                 "INSERT INTO %s.%s (time, topic_name, contributor_growth, project_activity, openrank_trend, star_growth) "
                 "VALUES (%lld, '%s', %.2f, %.2f, %.2f, %.2f);",
                 IOTDB_STORAGE_GROUP, IOTDB_TABLE,
                 timestamp, fields[0], contributor_growth, project_activity, openrank_trend, star_growth);
        int ret = session_execute_non_query(session, insert_sql);
        if (ret != SUCCESS_STATUS) {
            printf("警告：第%d行插入失败，SQL：%s\n", row_count, insert_sql);
        } else {
            printf("第%d行插入成功\n", row_count);
        }
        for (int i = 0; i < field_count; i++) {
            free(fields[i]);
        }
        free(fields);
    }

    fclose(fp);
    printf("CSV导入完成，共处理%d行\n", row_count);
    return 0;
}
char *iotdb_query_topic_data(void *conn, const char *start_date, const char *end_date) {
    if (conn == NULL || start_date == NULL || end_date == NULL) {
        printf("错误：参数为空\n");
        return NULL;
    }
    Session *session = (Session *)conn;

    char query_sql[1024];
    snprintf(query_sql, sizeof(query_sql),
             "SELECT time, topic_name, contributor_growth, project_activity, openrank_trend, star_growth "
             "FROM %s.%s WHERE time >= %lld AND time <= %lld;",
             IOTDB_STORAGE_GROUP, IOTDB_TABLE,
             (long long)strtoll(start_date, NULL, 10), (long long)strtoll(end_date, NULL, 10));

    SessionDataSet *data_set = session_execute_query(session, query_sql);
    if (data_set == NULL) {
        printf("错误：查询失败，SQL：%s\n", query_sql);
        return NULL;
    }

    char *result = (char *)malloc(4096);
    if (result == NULL) {
        printf("错误：内存分配失败\n");
        session_close_dataset(data_set);
        return NULL;
    }
    result[0] = '\0';
    strcat(result, "时间戳,领域名称,新增贡献者增长率,项目活跃度,OpenRank趋势,星标增长速度\n");

    int row = 0;
    while (session_dataset_next(data_set) && row < 10) {
        long long time = session_dataset_get_long(data_set, 0);
        const char *topic_name = session_dataset_get_string(data_set, 1);
        double contributor_growth = session_dataset_get_double(data_set, 2);
        double project_activity = session_dataset_get_double(data_set, 3);
        double openrank_trend = session_dataset_get_double(data_set, 4);
        double star_growth = session_dataset_get_double(data_set, 5);

        char row_str[256];
        snprintf(row_str, sizeof(row_str), "%lld,%s,%.2f,%.2f,%.2f,%.2f\n",
                 time, topic_name, contributor_growth, project_activity, openrank_trend, star_growth);
        strcat(result, row_str);
        row++;
    }

    session_close_dataset(data_set);
    printf("查询完成，返回%d行\n", row);
    return result;
}