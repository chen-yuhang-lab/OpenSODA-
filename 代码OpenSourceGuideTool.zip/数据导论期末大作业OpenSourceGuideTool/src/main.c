#include "data_process.h"
typedef struct {
    char domain_name[50];
    char json_path[100];
    int comprehensive_score; 
    float pr_avg_duration;   
} DomainConfig;

int main() {
    DomainConfig domains[3] = {
        {
            "ai-toolchain",
            "C:/Users/86156/Desktop/top_300_metrics/apache/spark/activity_details.json", // spark的JSON路径
            92, 
            4.2
        },
        {
            "lightweight-framework",
            "C:/Users/86156/Desktop/top_300_metrics/apache/spark/activity_details.json", // electron的JSON路径
            85, 
            3.5 
        },
        {
            "china-open-source",
            "C:/Users/86156/Desktop/top_300_metrics/apache/spark/activity_details.json", // fastjson的JSON路径
            76, 
            2.8 
        }
    };
    DomainMetric metrics[3];
    int metric_count = 0;
    for (int i = 0; i < 3; i++) {
        printf("正在提取【%s】领域数据...\n", domains[i].domain_name);
        float avg_activity = extract_activity_average(domains[i].json_path);
        int contributor_num = count_contributors(domains[i].json_path);
        strcpy(metrics[i].domain_name, domains[i].domain_name);
        metrics[i].contributor_count = contributor_num;
        metrics[i].activity_score = (int)(avg_activity * 20); 
        metrics[i].comprehensive_score = domains[i].comprehensive_score;
        metrics[i].pr_avg_duration = domains[i].pr_avg_duration;
        printf("贡献者数量：%d，活跃度均值：%.2f，综合评分：%d\n\n",
               contributor_num, avg_activity, domains[i].comprehensive_score);
        
        metric_count++;
    }
    int ret = write_topic_data("data/raw_data/topic_data.csv", metrics, metric_count);
    if (ret == 0) {
        printf("数据已成功写入data/raw_data/topic_data.csv！\n");
    } else {
        printf("数据写入失败！\n");
    }

    return 0;
}