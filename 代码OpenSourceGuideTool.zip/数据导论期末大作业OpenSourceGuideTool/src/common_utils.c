#include "../include/common_utils.h"
int split_string(const char* str, char delim, char ***result, int max_count) {
    if (str == NULL || result == NULL) return -1;
    *result = (char**)malloc(max_count * sizeof(char*));
    int count = 0;
    char *copy = strdup(str);
    char *token = strtok(copy, &delim);

    while (token != NULL && count < max_count) {
        (*result)[count] = strdup(token);
        count++;
        token = strtok(NULL, &delim);
    }

    free(copy);
    return count;
}