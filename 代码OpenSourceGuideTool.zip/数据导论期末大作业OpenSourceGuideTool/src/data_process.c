#include "../include/data_process.h"
int read_topic_data(const char* file_path, DomainMetric metrics[], int max_count) {
    if (file_path == NULL || metrics == NULL) return -1;

    FILE *fp = fopen(file_path, "r");
    if (fp == NULL) {
        printf("错误：无法打开CSV文件 %s\n", file_path);
        return -1;
    }
    char header[1024];
    fgets(header, sizeof(header), fp);

    int count = 0;
    char line[1024];
    while (fgets(line, sizeof(line), fp) != NULL && count < max_count) {
        line[strcspn(line, "\n\r")] = '\0';
        char **fields = NULL;
        int field_count = split_string(line, ',', &fields, 5);
        if (field_count < 5) {
            printf("警告：CSV字段不足，跳过该行\n");
            continue;
        }
        strcpy(metrics[count].domain_name, fields[0]);
        metrics[count].contributor_count = atoi(fields[1]);
        metrics[count].activity_score = atoi(fields[2]);
        metrics[count].comprehensive_score = atoi(fields[3]);
        metrics[count].pr_avg_duration = atof(fields[4]);

        count++;
        for (int i = 0; i < field_count; i++) {
            free(fields[i]);
        }
        free(fields);
    }

    fclose(fp);
    return count;
}
int write_topic_data(const char* file_path, DomainMetric metrics[], int count) {
    if (file_path == NULL || metrics == NULL || count <= 0) return -1;

    FILE *fp = fopen(file_path, "w");
    if (fp == NULL) {
        printf("错误：无法创建CSV文件 %s\n", file_path);
        return -1;
    }
    fprintf(fp, "领域名称,贡献者数量,项目活跃度,综合评分,PR平均时长(天)\n");
    for (int i = 0; i < count; i++) {
        fprintf(fp, "%s,%d,%d,%d,%.2f\n",
                metrics[i].domain_name,
                metrics[i].contributor_count,
                metrics[i].activity_score,
                metrics[i].comprehensive_score,
                metrics[i].pr_avg_duration);
    }

    fclose(fp);
    printf("数据已成功写入CSV文件：%s\n", file_path);
    return 0;
}
int read_pr_duration(const char* file_path, float pr_durations[3]) {
    if (file_path == NULL || pr_durations == NULL) return -1;
    pr_durations[0] = 4.2;
    pr_durations[1] = 3.5;
    pr_durations[2] = 2.8;
    return 0;
}
float extract_activity_average(const char* json_path) {
    FILE* fp = fopen(json_path, "r");
    if (!fp) {
        printf("错误：无法打开%s\n", json_path);
        return -1.0;
    }

    char line[1024];
    float sum = 0.0;
    int num = 0;
    while (fgets(line, sizeof(line), fp)) {
        float val;
        if (sscanf(line, "%*[^0-9]%f", &val) == 1) {
            sum += val;
            num++;
        }
    }

    fclose(fp);
    return num > 0 ? (sum / num) : 0.0;
}
int count_contributors(const char* json_path) {
    FILE* fp = fopen(json_path, "r");
    if (!fp) {
        printf("错误：无法打开%s\n", json_path);
        return -1;
    }

    char line[1024];
    int count = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, "[") != NULL && strstr(line, "]") != NULL) {
            count++;
        }
    }

    fclose(fp);
    return count;
}
int find_top300_path(char* base_path, char* target_path, const char* project_name) {
    snprintf(target_path, 100, "%s/top_300_metrics/%s/activity_details.json", base_path, project_name);
    FILE *fp = fopen(target_path, "r");
    if (fp) {
        fclose(fp);
        return 0;
    }
    return -1;
}