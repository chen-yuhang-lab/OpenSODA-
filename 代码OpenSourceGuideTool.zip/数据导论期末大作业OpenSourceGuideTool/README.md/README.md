一、项目结构
opensourceguidetool   # 项目根目录，项目名称：开源初学者的学习导航——开源新手技术趋势与入门指导平台
├── data                   # 数据文件夹（存储导出、处理后的数据）
│   ├── raw_data/           # 原始数据（OpenDigger）
│   │   ├── topic_data.csv       # 技术领域原始数据
│   │   ├── repo_list.csv         # 领域热度原始数据
│   │   └── pr_duration.csv      # 新手入门周期原始数据
├── 基础代码
│   ├── include
│   └── src
├── build_and_run.sh
│   └── extract_data.py  #提取数据到数据文件
├──path_guide.md       # 项目分步入门指南
├── 网页(index.html)  # 核心Web页面（整合可视化、入门指南）
└── README.md         # 项目总说明
二、核心运行：打开Web一站式界面
1. 找到项目中的index.html文件；
2. 双击该文件，自动用默认浏览器打开；
3. 页面加载后，可直接使用：
技术趋势可视化：直接显示DataEase嵌入的表格，排行榜和扇形图；
入门路径查看：点击页面中的“项目入门指南”链接，自动打开guide/path_guide.md文件。