echo "===== 开始编译 ====="
gcc src/main.c src/data_process.c src/common_utils.c src/iotdb_client.c -o main -Iinclude

if [ $? -eq 0 ]; then
    echo "===== 编译成功，运行程序 ====="
    ./main
else
    echo "===== 编译失败 ====="
fi